package com.kelaniya.android.myapplication.model

data class OtpRequest(val email:String)
