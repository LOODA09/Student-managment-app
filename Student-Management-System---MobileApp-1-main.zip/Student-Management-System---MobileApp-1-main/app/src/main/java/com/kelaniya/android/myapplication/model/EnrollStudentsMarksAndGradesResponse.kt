package com.kelaniya.android.myapplication.model

data class EnrollStudentsMarksAndGradesResponse(val student_id:String,val student_email:String,  val course_id:String,val score:Double,val grade:String)
