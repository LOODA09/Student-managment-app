package com.kelaniya.android.myapplication.model


data class LecNotes (
    val file_name:String,
    val subjectName:String,
    val description:String,
    val file_type:String,
    val file_size:Long,
    val academic_year:String,
    val date:String,
    val data:String
    )
