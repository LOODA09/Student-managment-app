package com.kelaniya.android.myapplication.model

data class User(val username:String,val role:Set<Role>)