package com.kelaniya.android.myapplication.model

data class OtpResponse(val email:String, val otp:String)
