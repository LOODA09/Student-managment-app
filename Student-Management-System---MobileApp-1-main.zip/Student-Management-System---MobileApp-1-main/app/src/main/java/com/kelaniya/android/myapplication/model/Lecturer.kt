package com.kelaniya.android.myapplication.model

data class Lecturer(val student_email:String, val student_id:String, val first_name:String, val last_name:String, val department:String, val profile_pic:String)
