package com.kelaniya.android.myapplication.model

data class StudentRecordsUpdateRequest(val student_email: String,val course_id: String,val score:Double,val grade: String)


