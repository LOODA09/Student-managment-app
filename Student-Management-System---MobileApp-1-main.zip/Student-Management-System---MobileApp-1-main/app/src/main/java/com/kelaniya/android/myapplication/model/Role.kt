package com.kelaniya.android.myapplication.model

data class Role(val roleName:String,val roleDescription:String)
