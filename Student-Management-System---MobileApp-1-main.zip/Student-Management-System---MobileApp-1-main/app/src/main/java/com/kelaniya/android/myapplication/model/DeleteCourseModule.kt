package com.kelaniya.android.myapplication.model

data class DeleteCourseModule(val course_id:String, val academic_year:String)
