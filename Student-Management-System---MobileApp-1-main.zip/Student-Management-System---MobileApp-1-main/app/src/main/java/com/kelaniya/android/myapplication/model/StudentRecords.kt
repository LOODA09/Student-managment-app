package com.kelaniya.android.myapplication.model

data class StudentRecords(var id:Int,var student_email:String,var course_id:String,var score:Double,var grade:String)
