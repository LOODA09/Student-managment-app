package com.kelaniya.android.myapplication.model

data class DeleteAnnouncementRequest(val title:String, val course_id:String)
