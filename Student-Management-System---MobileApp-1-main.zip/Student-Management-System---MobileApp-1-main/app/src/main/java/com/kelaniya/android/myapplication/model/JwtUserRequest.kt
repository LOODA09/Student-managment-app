package com.kelaniya.android.myapplication.model

data class JwtUserRequest(val username:String,val password:String)
