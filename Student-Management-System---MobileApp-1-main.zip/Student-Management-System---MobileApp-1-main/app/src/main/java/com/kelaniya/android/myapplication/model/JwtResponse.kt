package com.kelaniya.android.myapplication.model

data class JwtResponse(val responseUser: User,val jwtToken:String,val message:String)
