package com.kelaniya.android.myapplication.model

data class MarkAsNotificationAreReadResponse(val value:Int)
