package com.kelaniya.android.myapplication.model

data class UnenrollFromCourseRequest(val academic_year:String, val enrolled_course_id:String)
