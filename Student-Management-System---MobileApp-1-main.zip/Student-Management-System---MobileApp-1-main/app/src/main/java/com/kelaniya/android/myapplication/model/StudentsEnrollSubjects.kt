package com.kelaniya.android.myapplication.model

data class StudentsEnrollSubjects(val student_email:String, val enrolled_course_id:String,val academic_year:String)
