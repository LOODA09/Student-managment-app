package com.kelaniya.android.myapplication.model

data class GetLectureNotesRequest(val subject_name:String,val academic_year:String)
