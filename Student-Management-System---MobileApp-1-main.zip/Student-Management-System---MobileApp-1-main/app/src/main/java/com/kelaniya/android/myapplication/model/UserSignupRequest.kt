package com.kelaniya.android.myapplication.model

data class UserSignupRequest(val email :String, val role : String, val firstName: String, val lastName : String, val id : String, val password: String)
