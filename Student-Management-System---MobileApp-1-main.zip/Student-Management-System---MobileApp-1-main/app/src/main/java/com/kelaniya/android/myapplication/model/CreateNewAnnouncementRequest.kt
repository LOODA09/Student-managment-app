package com.kelaniya.android.myapplication.model

data class CreateNewAnnouncementRequest(var title:String,var body:String,var category:String,var academic_year:String)
