package com.kelaniya.android.myapplication.model

data class UserSignupResponse(  val username :String, val password: String)
