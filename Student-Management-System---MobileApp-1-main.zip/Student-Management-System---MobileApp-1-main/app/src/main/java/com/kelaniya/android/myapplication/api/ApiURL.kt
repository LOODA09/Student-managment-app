package com.kelaniya.android.myapplication.api

import android.app.Application
import android.content.Context

open class ApiURL :Application(){


//    192.168.142.229 = hotspot
//    192.168.1.11 = wifi
    val API_URL = "http://192.168.142.229:8095"


}