package com.kelaniya.android.myapplication.model

data class Announcement(var id:Int,var lecturer_email:String,var title:String,var body:String,var category:String,var academic_year:String,var view_state:String)
