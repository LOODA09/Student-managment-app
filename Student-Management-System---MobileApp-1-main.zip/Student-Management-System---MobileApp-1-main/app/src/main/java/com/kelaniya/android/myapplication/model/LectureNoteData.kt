package com.kelaniya.android.myapplication.model

import okhttp3.Response

data class LectureNoteData(val response: String)
