package com.kelaniya.android.myapplication.api

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.kelaniya.android.myapplication.R


class InternetConnection : Fragment() {

}