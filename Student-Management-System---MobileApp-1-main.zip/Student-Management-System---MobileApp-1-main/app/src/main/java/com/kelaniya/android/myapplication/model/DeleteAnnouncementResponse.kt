package com.kelaniya.android.myapplication.model

data class DeleteAnnouncementResponse(val lecturer_email:String,val title:String,val academic_year:String  )
