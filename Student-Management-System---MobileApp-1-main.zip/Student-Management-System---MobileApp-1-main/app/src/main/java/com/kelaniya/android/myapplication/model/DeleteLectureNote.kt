package com.kelaniya.android.myapplication.model

data class DeleteLectureNote(val file_name:String)
